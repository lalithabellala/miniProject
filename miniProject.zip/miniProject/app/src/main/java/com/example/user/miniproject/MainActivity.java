package com.example.user.miniproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    EditText editText;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=findViewById(R.id.tv);
        editText=findViewById(R.id.ed);
        button=findViewById(R.id.button);
    }

    public void display(View view) {
        if(editText.getText().length()==0){
            Toast.makeText(this, "Enter something in edit text", Toast.LENGTH_SHORT).show();
        }
        else {
            String str = editText.getText().toString();
            textView.setText(str);
        }
    }
    }

